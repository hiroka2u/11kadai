<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
    <?php echo $__env->make('common.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <form action="<?php echo e(url('books/update')); ?>" method="POST">

        <!-- item_name -->
        <div class="form-group">
           <label for="item_name">Title</label>
           <input type="text" id="item_name" name="item_name" class="form-control" value="<?php echo e($book->item_name); ?>">
        </div>
        <!--/ item_name -->
        
        <!-- item_number -->
        <div class="form-group">
           <label for="item_number">Number</label>
        <input type="text" id="item_number" name="item_number" class="form-control" value="<?php echo e($book->item_number); ?>">
        </div>
        <!--/ item_number -->

        <!-- item_amount -->
        <div class="form-group">
           <label for="item_amount">Amount</label>
        <input type="text" id="item_amount" name="item_amount" class="form-control" value="<?php echo e($book->item_amount); ?>">
        </div>
        <!--/ item_amount -->
        
        <!-- published -->
        <div class="form-group">
           <label for="published">published</label>
            <input type="datetime" id="published" name="published" class="form-control" value="<?php echo e($book->published); ?>"/>
        </div>
        <!--/ published -->
        
        <!-- Saveボタン/Backボタン -->
        <div class="well well-sm">
            <button type="submit" class="btn btn-primary">Save</button>
            <a class="btn btn-link pull-right" href="<?php echo e(url('/')); ?>">
                <i class="glyphicon glyphicon-backward"></i>  Back
            </a>
        </div>
        <!--/ Saveボタン/Backボタン -->
         
         <!-- id値を送信 -->
         <input type="hidden" name="id" value="<?php echo e($book->id); ?>" />
         <!--/ id値を送信 -->
         
         <!-- CSRF -->
         <?php echo e(csrf_field()); ?>

         <!--/ CSRF -->
         
    </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>